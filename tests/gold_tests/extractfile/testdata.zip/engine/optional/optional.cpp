
#include "optional.h"
#include <common.h>

void optional()
{
	common("optional");
}