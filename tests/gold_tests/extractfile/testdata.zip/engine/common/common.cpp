
#include "common.h"
#include <iostream>

void common(std::string const& s)
{
	std::cout<<"Common called from "<<s<<std::endl;
}