#include <engine/engine.h>
#include <iostream>

int main()
{
	engine();
	core();
	common("hello in test");
	std::cout<<"test passed"<<std::endl;
	return 0;
}


