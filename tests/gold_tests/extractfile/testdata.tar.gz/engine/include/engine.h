
#include "common.h"
#include "core.h"

inline void engine() {common("engine");core();}
