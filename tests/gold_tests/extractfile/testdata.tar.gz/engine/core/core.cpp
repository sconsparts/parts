
#include "core.h"
#include <common.h>

void core()
{
	common("core");
}